Put your state .hx files in here.

Read more:
https://github.com/Brainy0789/BrainyEnginePlus/wiki/Custom-States